% EQUAL(A,B) returns true if matrices A and B are equal, elementwise.
% A and B must have the same dimensions. Otherwise an error is thrown.
% EQUAL(A,B,tol) returns true if the elements of A and B do not differ by
% more than tol and false otherwise.

function t = equal(A , B, tol)

if nargin < 2
   error('need two arrays A and B to compare');
elseif nargin < 3
   % If tol not defined, set to 0.
   tol = 0;    
end

if tol < 0
   error('tol must be nonnegative number'); 
end

adim = size(A);
bdim = size(B);

% Compare the dimensions of A and B.
if length(adim) ~= length(bdim) || any(abs(adim - bdim))
   error('A, B dimension mismatch'); 
end

% Compare A and B elementwise.
if max(abs(A(:) - B(:))) > tol
    t = false;
else
    t = true;
end

% Generate a random <f x n> matrix X, whose rows are samples of the unit 
% simplex.
% The matrix is constructed by randomly drawing r random points from the
% unit simplex (hott topics). The remaining f-r rows are subsequently
% created as random convex combinations of the r hott topics.
% The f generated rows are permuted so that the hott rows are randomly
% placed in X. The indices of the hott rows in X are returned in "hott".
function [X, hott]= genSeparableX(f, n, r)

X = zeros(f, n);
W = eye(r, n);

is = false;
while(~is)
    for i = 1:r
        W(i,:) = randomconvex(n);
    end
    is = aresimplicial(W);
    if (~is), 
        warning('failed to create simplicial set. Attempting again');
    end;
end

X(1:r,:)=W;
for i = r+1:f
    X(i,:) = randomconvex(r)'*W; 
end
perm = randperm(f);
X = X(perm,:);

[~, hott] = sort(perm);
hott = sort(hott(1:r));

%--------------------------------------------------------------------------
% EE599 - Sparse Approximations
% Fall, 2012.
% For the semester project on Nonnegative Matrix Factorizaton.
%
% Author: Megasthenis Asteris
% December 17, 2012.
%--------------------------------------------------------------------------

% Run the 4 algorithms against random input matrices X that admit a
% separable factorization.

%% SET UP
f = 30;
r = 10;
n = 50;
tol = 10^-3;

EXP = 50;
NUM_OF_ALGORITHMS = 4;
Algorithms = [{'SEPNMFLP (known-r)'}; {'SEPNMFLP (search-r)'}; {'SEPNMFLP-MOD'}; {'ESSER'}];

%--------------------------------------------------------------------------
% Initialization
run_time    = zeros(NUM_OF_ALGORITHMS, EXP);
sup_det     = zeros(NUM_OF_ALGORITHMS, EXP);
error_forb  = zeros(NUM_OF_ALGORITHMS, EXP);
error_inf1  = zeros(NUM_OF_ALGORITHMS, EXP);
r_o         = zeros(NUM_OF_ALGORITHMS, EXP);

ee = 0;
while ee < EXP
        
    ee = ee + 1;
    [X, Xhott] = genSeparableX(f, n, r);
    %X = [X; X(Xhott, :)];

    %======================================================================

    
    fprintf('%03d:', ee);
    
    for algo = 1:NUM_OF_ALGORITHMS
        fprintf(' %d,', algo);
        tic;
        switch(algo)
            case 1
                % Algorithm 1
                % The main algorithm by Bittor et. al. 
                % r is assumed to be known.
                [F,W, hott, feasible, C] = sepnmflp(X, r, tol);
                if ~feasible
                   ee = ee - 1;
                   fprintf('(not solved)\n');
                   break;
                end
                
            case 2
                % Algorithm 2
                % Repeatedly run the algorithm by Bittorf et. al. for
                % gradually increasing r till a feasible solution is
                % returned.
                for r_cand = 2:f
                    [F,W, hott, feasible, C] = sepnmflp(X, r_cand, tol);
                    if r_cand == f && ~feasible
                       break; 
                    end
                    if feasible
                        break;
                    end
                end
            case 3
                % Algorithm 3
                % My modified version of Algorithm 1.
                [F,W, hott, feasible, C] = sepnmflp(X, [], tol);
            case 4
                % Algorithm 4
                % The Esser et. al Algorithm.
                [F,W, hott, feasible] = myesser(X, tol);
        end        

        run_time(algo, ee) = toc;
        if feasible
            r_o(algo, ee) = size(F, 2);
            if ~any(abs(Xhott - hott'))
                sup_det(algo, ee) = 1;
            else
                sup_det(algo, ee) = 0;
            end
            error_forb(algo, ee) = sum(sum((X-F*W).^2));
            error_inf1(algo, ee) = max(sum(abs(X-F*W), 2));
        else
            sup_det(algo, ee) = 0;
        end
        %tau = 4*1e-5;
        %[F,W, hott, feasible] = approxsepnmflp(X, tau, tol);

        
    end   
    %======================================================================
    fprintf('\n');
end

figure;
bar(mean(run_time, 2)')
xlabel('Algorithms', 'Interpreter', 'Latex')
ylabel('Average Time (seconds)', 'Interpreter', 'Latex');
title(sprintf('Factorization Times - f=%d, n=%d, r=%d (%d experiments)',f, n, r, EXP), 'Interpreter', 'Latex');
grid on;
save2pdf(sprintf('../Report/Images/randomSimplicial_exec_times_f%dn%dr%dexp%d-lowprec-algos%d',f, n, r, EXP,NUM_OF_ALGORITHMS), gcf, 600)

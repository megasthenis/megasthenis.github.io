% RANDOMCONVEX(N)
% Generate a random nonnegative n-dimensional vector whose elements sum to
% 1. Warning, the vector is not assumed to be uniformly distributed.
function c = randomconvex(n)

M = intmax-1;
r = randi([1 M], n-1,1);
[s, ~] = sort(r);
c = [s;M] - [M-M; s];
c = double(c(randperm(n)))/double(M);
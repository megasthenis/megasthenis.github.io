% Seek for a matrix C such that CX = X and the (inf,1)-norm of C is
% minimized.
% The objective is to find a matrix C such that the number of non-zero
% columns is minimized. The (inf,1)-norm minimization is an exact
% relaxation for the noiseless case.
function [F,W, hott, feasible] = myesser(X, tol)

SCALE = size(X,2);
X = X*SCALE;

%% Initialization
feasible = true;
F = [];
W = [];

if nargin < 2
    tol = 10^-4;
end

if tol < 0
   error('tol must be nonnegative number'); 
end

[f,n] = size(X);

if f > n
   error('f should be smaller than n (X is <f x n>)'); 
end


%% Linear program
cvx_begin
    cvx_solver('sdpt3')
    cvx_quiet(true)
    cvx_precision('low')
    
    variable C(f,f);
    minimize sum(max(C, [], 1));
    %minimize [1:f]*transpose((max(C, [], 1)));
    subject to
        C*X-X == 0;
        C >= 0;
cvx_end

if ~(strcmp(cvx_status, 'Solved') == 1)
    feasible = false;
    return
end

%% Constructing the factors out of the LP result

% Determine hott topics: entries on diagonal of C equal to 1
hottsupport = abs(diag(C) - 1) <= tol;


hott = find(hottsupport);

% Construct F and W
F = C(:, hott);
W = X(hott, :)/SCALE;


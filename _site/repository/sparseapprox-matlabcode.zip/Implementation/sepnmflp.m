% SEPNMFLP(X, r, tol)
% Separable Non-negative Matrix Factorization by Linear Programming
% (Implementation of Algorithm 2 in Bittorf et al).
% Input is an <f x n> matrix X that has a simplicial factorization.
% The algorithm returns an <f x r> nonnegative matrix F and <r x n> matrix
% nonnegative matrix W such that X = FW.
% Parameter tol defines what numbers are considered 0.
% If parameter r is empty (r=[]), then the constraint Tr(C)=r in the linear
% program is dropped.
function [F,W, hott, feasible, C] = sepnmflp(X, r, tol)

SCALE = size(X,2);
X = X*SCALE;
%% Initialization
F = [];
W = [];
hott = [];
feasible = true;

if nargin < 2
    tol = 10^-4;
end

if tol < 0
   error('tol must be nonnegative number'); 
end

[f,n] = size(X);

if f > n
   error('f should be smaller than n (X is <f x n>)'); 
end

if r > f
   error('r should be smaller than f (X is <f x n>)'); 
end

%% Linear program
cvx_begin
    cvx_solver('sdpt3')
    cvx_quiet(true)
    cvx_precision('low')
%
  variable C(f,f);
  minimize [1:f]*diag(C);
  subject to
    C*X-X == 0;
    C >= 0;
    if ~isempty(r)
        diag(C) <= 1;
        trace(C) == r;
        %abs(trace(C) - r) <= tol;
    end
    C <= repmat(diag(C)', f, 1);
cvx_end

if ~(strcmp(cvx_status, 'Solved') == 1)
    feasible = false;
    return
end

%% Constructing the factors out of the LP result

% Determine hott topics: entries on diagonal of C equal to 1
hottsupport = abs(diag(C) - 1) <= tol;

if ~isempty(r), assert(equal(sum(hottsupport), r, tol)); end

hott = find(hottsupport);

% Construct F and W
F = C(:, hott);
W = X(hott, :)/SCALE;


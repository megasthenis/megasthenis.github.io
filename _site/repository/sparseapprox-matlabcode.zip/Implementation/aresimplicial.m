% ARESIMPLICIAL(W)
% Check if the rows of W form a simplicial set.
% Return true if the do, and false otherwise.
function is= aresimplicial(W)

[r,~] = size(W);

for i = 1:r
    % Check if the i-th row belongs to the convex hull of the remaining r-1
    % rows.
    cvx_begin
      cvx_quiet(true);
      variable c(r-1,1);
      minimize norm(c,1);
      subject to
        c'*W([1:i-1,i+1:r], :) == W(i,:);
        c >= 0;
    cvx_end
    
    % If there exists a row that belongs to the convex hull of the 
    % remaining r-1 rows, the set is not simplicial.
    if ~(strcmp(cvx_status, 'Infeasible') == 1)
        is = false;
        return
    end
end
is = true;
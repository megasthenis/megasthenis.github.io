%% [X, OPTVAL] = FINDOPTSOLFROMCANDSETS(V, SUPPORTS)
% Iterate over the support sets in the rows of SUPPORTS
% and for each support compute the unit norm x that
% maximizes(x'*V*V'*x). Return the vector x that achieves
% the optimal value in the quadratic form among all
% given support sets.
% V is a N x D matrix with rank equal to D.

% Author :	Megasthenis Asteris
%
% Created:	March 10, 2010

function [x, optVal] = findOptSolFromCandSets(V, supports)

[N, D] = size(V);
x      = zeros(N,1);
optVal = 0;

for i=1:size(supports, 1)
    
    [U S] = svd( V(supports(i,:),:) );
    
    %S(1,1) is the maximum possible value of the quadratic form.
    if ( abs(S(1,1)) > optVal ) 
       optVal = S(1,1);
       x(:) = 0;
       x(supports(i,:)) = U(:,1)/norm(U(:,1));
    end
    
end

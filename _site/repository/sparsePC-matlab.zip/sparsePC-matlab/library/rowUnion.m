%% [C, I] = ROWUNION(A, B)
% Create a matrix C whose rows are the rows of A and those rows of B
% that are not rows of A.
function C = rowUnion(A, B)

[ar, ac] = size(A);
[br, bc] = size(B);

if( ~isempty(A) && ac ~= bc)
    error('rowUnion:DimensionalityError','B have less columns than A');
end

C = [A; zeros(br, bc)];

for i = 1:br
    if(~isarow(C(1:ar, :), B(i,:)))
        ar = ar+1;
        C(ar, :) = B(i, :);
    end
end
C = C(1:ar, :);

%==========================================================================
% Given a matrix A and a vector r, check if r is a row of matrix A.
% INPUTS:
% - A : a matrix
% - r : a vector
% OUTPUTS:
% - is: logical true if ar is a row of A, false otherwise
function is = isarow(A, r)

[~, ac] = size(A);
set = A(A(:,1:min(1,ac)) == r(1),:);
for i = 2:ac
    set = set(set(:,i) == r(i),:);
end
is = ~isempty(set);
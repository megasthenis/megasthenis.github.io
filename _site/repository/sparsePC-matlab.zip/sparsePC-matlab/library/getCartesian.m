%% GETCARTESIAN
% Get the cartesian coordinates "cart" of the point that corresponds to the
% sperical coordinates "phi".
%
% Input:
%   - phi  : spherical coordinates <1 x D-1>
%
% Output:
%   - cart : cartesian coordinates <1 x D>

function cart = getCartesian(phi)

d = length(phi);
cart=zeros(d+1,1);
prcos = 1;
for i = 1:d
	cart(i, 1) = prcos * sin(phi(i));
    prcos = prod([prcos cos(phi(i))]);
end
cart(d+1, 1) = prcos;
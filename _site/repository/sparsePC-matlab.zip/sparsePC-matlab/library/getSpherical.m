%% GETSPHERICAL
% Get the spherical coordinates "phi" of the point that corresponds to the
% cartesian coordinates "cart".
%
% Input:
%   - cart : cartesian coordinates <1 x D>
%
% Output:
%   - phi  : spherical coordinates <1 x D-1>   

function phi = getSpherical(c)

D = length(c);
phi=zeros(D-1,1);
prcos = 1;
for phi_ind = 1:D-1
   phi(phi_ind)=asin(c(phi_ind)/prcos);
   prcos = prod([prcos cos(phi(phi_ind))]);
end
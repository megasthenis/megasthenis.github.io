ind
%% [S, STAT] = computeCandidateSupportsRank2Serial(V, K, DEMO)
% Computes candidate support sets for the vector x that solves
%             max (x'*V*V'*x)
%             st: || x ||_0 <= K,
%                 || x ||_2 = 1
% where V is a N x D matrix with rank equal to D.
% The size of each candidate support set is 0<= K <= N, where K is given as
% a parameter. 

% Author :	Megasthenis Asteris
%
% Created:	May 27, 2010 

function [S STAT] = computeCandidateSupports(V, K, DEMO)

% V is an N x D matrix where N >= D ( Rank(V) =D )
% K is a positive integer where K <= N.
[N, D] = size(V);
if(D > N), error('V:NxD, D must be <=N'); end;
if(K<0||K>N||ceil(K)~=K), error('K must be positive integer, K<=N'); end

%% Initialization
S  = [];

%--------------------------------------------------------------------------
% STAT is a collection of values used for statistical and debugging
% purposes. NOT used by the algorithm.
% Stat(i) is a struct that contains two fields:
% - val: a numeric field
% - msg: a string describing what val represents.
STAT(1) = struct('val',0, 'msg', 'Number of ambiguities');
%--------------------------------------------------------------------------
if (D == 1)
    % Get the rank-1 Candidate: the K absolutely largest values of V (Nx1).
    % Sorting not necessary, but used for simplicity.
    S = [topk(V, K)'];
    return;
end

% D > 1

% All {N choose D} combinations of D hypersurfaces (rows of V).
HSCombs = nchklite(N, D);

B = de2bi(0:2^(D-1)-1, D-1, 'left-msb'); B(B==0) = -1;

for cc = 1:size(HSCombs, 1)

    comb = HSCombs(cc,:);   % Current Index Combination
    
    % Each index-combination gives 2^(D-1) intersection cases:
    for s = 1:size(B, 1)
        b = B(s,:);
        
        % Create VI that contains the waveforms that will intersect
        Vsub = ones(D-1, 1)*V(comb(1), :) + diag(b)*V(comb(2:D),:);
                    
        % Get the cartesian coordinates of the intersection point
        c = findIntersection(Vsub);
        c = c*determineSign(c);
        
        % Find topK
        I = topk( V*c, K );
        [T, Iind] = intersect(I, comb);
        
        r = length(Iind); % Number of intersecting hypersurfaces in I
        
        if ( r>0 && r < D )
            % Create all possible {D choose r} subsets of the D
            % intersecting hypersurfaces. Each such subset yields
            % a new candidate support set.
            subComb = nchklite(D, r);
            for i = 1:size(subComb,1)
                I(Iind) = comb(subComb(i, :));
                S = rowUnion(S, sort(I'));
            end
            
            %--------------------------------------------------------------
            STAT(1).val = STAT(1).val + 1;
            %--------------------------------------------------------------
        else % if r == 0 || r == D
            S = rowUnion(S, sort(I'));
        end    
    end
 
end



%% topk(u)
% return the k absolutely largest elements of vector u.
% Here, we sort the elements of u for simplicity.
% However, sorting is not necessery.
function I = topk(u, k)

[~, I] = sort(abs(u), 'descend');
I = I(1:k);


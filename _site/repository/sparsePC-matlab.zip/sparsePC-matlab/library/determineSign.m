%% DETERMINESIGN
% sign_c = determineSign(c) returns the correct sign of the hyperpolar
% vector c
%
% Input:
%   - c  : cartesian coordinates <1 x D-1>
%
% Output:
%   - sign_c: correct sign vector of the cartesian coordinates

function sign_c = determineSign(c)

D = length(c);
phi=zeros(D-1,1);
for phi_ind = 1:D-1
   phi(phi_ind)=asin(c(phi_ind)/prod(cos(phi(1:phi_ind-1))));
end
if(D>1)
    sign_c = sign(tan(phi(D-1))*c(D-1)*c(D));
else
    sign_c = +1;
end
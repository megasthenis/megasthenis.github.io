%% [S, STAT] = computeCandidateSupportsRank2Serial(V, K, DEMO)
% Computes candidate support sets for the vector x that solves
%             max (x'*V*V'*x)
%             st: || x ||_0 <= K,
%                 || x ||_2 = 1
% where V is a N x 2 matrix with rank equal to 2.
% The function implements the enhanced serial-algorithm for determining the
% (polynomial-size) set of candidate support sets.
% The size of each candidate support set is 0<= K <= N, where K is given as
% a parameter. 
%
% DEMO : this parameter is irrelevant to the algorithm implementation. It
%        determines the level of demonstration.
%        Value : Effect
%            0 : No output.
%            1 : Print info in stardard output.
%            2 : Show figure - evolution snapshots.
%            3 : Pause at each visited intersection point.

% NOTE: Parts of the script between "DEMO START" and "DEMO END" can be 
% removed completely without affecting the algorithm.

% Author :	Megasthenis Asteris
%
% Created:	March 01, 2010
% Edited :	May 27, 2010

function [S, STAT] = computeCandidateSupportsRank2Serial(V, K, DEMO)

% Constants
[N, D]  = size(V);
MIN_PHI = - pi/2;       % End of phi-axis
MAX_PHI = MIN_PHI + pi; % End of phi-axis

if( D > N ), error('V:NxD, D must be <=N.'); end;
if( D ~=2 ), error('V:NxD, D must be equal to 2.'); end;
if( K<0 || K>N || ceil(K)~=K ),
    error('K must be positive integer, K<=N.');
end

%% Extras - Algorithm Irrelevant Settings
if nargin < 3
    DEMO = 0;
end

if DEMO >= 2 && N > 9
    warning('Try smaller N for better graphic demo results!');
end

STAT(1) = struct('val',0, 'name', 'Number of intersection computed');
STAT(2) = struct('val',0, 'name', 'Number of intersection points visited');
STAT(3) = struct('val',[], 'name', 'Points where the candidate set changes');
%==========================================================================


% Initialization ==========================================================
phiCur = MIN_PHI;

% Array to keep the intersection points calculated (to avoid recalculation)
isections = struct([]);
for i = 1:N
    isections(i).point = [];
end

% The candidate support set at the initializaton point.
[~, I] = sort(abs(V*[sin(MIN_PHI); cos(MIN_PHI)]), 1, 'descend');

S   = [];              % Set of candidate support sets I(\phi)'s.
%==========================================================================


% == DEMO PART START ======================================================
if(DEMO)
    
    if DEMO >= 1
        DEMO_step = 10^-4;
        DEMO_grid   = MIN_PHI:DEMO_step:MAX_PHI;
        DEMO_curves = abs(V*[sin(DEMO_grid); cos(DEMO_grid)]);
        DEMO_fig    = figure(); clf; shg
        plot(DEMO_grid, DEMO_curves, 'Linewidth', 2); hold on;
        
        DEMO_top    = max(max(DEMO_curves))*1.05;
        DEMO_bottom = 0;
        
        xlim([MIN_PHI MAX_PHI]);
        ylim([DEMO_bottom DEMO_top]);
        
        xlabel('\phi');
        ylabel('$|\mathbf{V}\mathbf{c}(\phi)|$', 'Interpreter', 'Latex');
        set(gca,'XTick',-pi/2:pi/4:pi/2)
    end
end

% == DEMO PART END ========================================================
while phiCur < MAX_PHI
    
    % I(K) is the index of the Kth order curve.
        
    if isempty(isections(I(K)).point)
        % If it is the first time this curve becomes the Kth order curve,
        % compute its isections with all other N-1 curves.
   
        isections(I(K)).point = zeros(1, 2*N);
        for i = 1:N
            if ~isempty(isections(i).point)
                % Intersection of the I(K)-th curve with the i-th curve
                % might have already been computed for the i-th curve.
                isections(I(K)).point(i)   = isections(i).point(I(K));
                isections(I(K)).point(i+N) = isections(i).point(I(K)+N);
            else
                % Otherwise, compute explicitly.
                isections(I(K)).point(i) = ...
                    atan( (V(I(K),2)-V(i,2))./  (V(i,1)-V(I(K),1)) );
                isections(I(K)).point(i+N) = ...
                    atan( (V(I(K),2)+V(i,2))./ -(V(i,1)+V(I(K),1)) );
                % ---------------------------------------------------------
                % Stat-Info: Increment # of intersection points computed.
                STAT(1).val = STAT(1).val + 1;
                % ---------------------------------------------------------
            end
        end        
    end 
    
    % Among the intersection points of the I(K) curve, determine the next
    % point, phiNxt, to be visited.
    phiNxt = Inf;
    for i = 1:2*N
        if mod(i, N) ~= I(K) && isections(I(K)).point(i) > phiCur
            if ( isections(I(K)).point(i) < phiNxt )
               phiNxt = isections(I(K)).point(i);
               KthNxt = i - (i > N)*N;
            end     
        end
    end
    

    % == DEMO PART START ==================================================
    if(DEMO > 0)
        fprintf('= Next point: %f\n', phiNxt);
        
        if DEMO > 1
            figure(DEMO_fig);
            DEMO_gp = phiCur:DEMO_step:min([MAX_PHI, phiNxt]);
           
            % Highlight the intersection point to be visited next
            DEMO_ipm = line([phiNxt phiNxt], ones(1,2)*abs(V(I(K),:)*...
                [sin(phiNxt); cos(phiNxt)]), 'Marker', 'p');
            DEMO_iphl = line([MIN_PHI MAX_PHI], ones(1,2)*abs(V(I(K),:)*...
                [sin(phiNxt); cos(phiNxt)]), 'LineStyle', '--');
            DEMO_ipvl = line(ones(1,2)*phiNxt, [DEMO_bottom, DEMO_top],...
                'LineStyle', '--');
            % Highlight Kth order curve in between current and next phi.
            plot(DEMO_gp, abs(V(I(K),:)*[sin(DEMO_gp); cos(DEMO_gp)]),...
                'k', 'Linewidth', 4, 'LineStyle', '-');
        end
    end
    % == DEMO PART END ====================================================
    
    phiCur  = phiNxt;
  
    if(phiCur > MAX_PHI) % end execution
        break; 
    end
    
    % ---------------------------------------------------------------------
    % Stat-Info: Increase the number of isections visited
    STAT(2).val = STAT(2).val + 1;
    % ---------------------------------------------------------------------
    
    % Update the Kth order curve (Keep track of the Kth order curve).
    i_swap    = find(I==KthNxt);
    I(i_swap) = I(K); 
    I(K)      = KthNxt;
       
    % Check if the candidate support set changes over phiCur.
    if( i_swap > K && phiCur < MAX_PHI)
        
        % -----------------------------------------------------------------
        % Mark point as a candidate support change point.
        STAT(3).val = [STAT(3).val ; phiCur];
        % -----------------------------------------------------------------
        
        % Store the new candidate support set in S :
        % S  = [S; transpose(I(1:K))];  
        % Although not efficient is matlab, we add a set in S, only if it
        % is not already there.
        S = rowUnion(S, transpose(sort(I(1:K))));          
    end
    
    
    % == DEMO PART START ==================================================
    if(DEMO)
        
        if ( DEMO >= 3 )
            pause;
        elseif ( DEMO >= 2 )
            pause(0.2);
        end
        
        delete(DEMO_ipm);
        delete(DEMO_iphl);
        delete(DEMO_ipvl);
        
        if(~isempty(STAT(3).val) && phiCur == STAT(3).val(end))
            fprintf('- New candidate support set:\n');
            fprintf('<- Old Kth curve: %d\n', I(i_swap));
            fprintf('-> New Kth curve: %d\n', I(K));
            % Mark the phi where I changed (vertical gray dashed line).
            if DEMO >= 2
                line(phiCur*[1 1], [DEMO_bottom, DEMO_top],...
                'Color', [0.8, 0.8, 0.8],...
                'LineStyle', '--',...
                'LineWidth', 1);
            end
        
        else
            fprintf('- Remain in same region. No change in I:\n');
            fprintf('o Old K-th curve: %d\n', I(i_swap));
            fprintf('o New K-th curve: %d\n', I(K)); 
        end            
    end
    % == DEMO PART END ====================================================
    
end %End of algorithm loop


% The Sparse Principal Component of a Constant-rank Matrix
% -------------------------------------------------------------------------
% Run the "rank-2 serial algorithm" on a small randomly created example. 
% For DEMO = 2 or 3, the script plots snapshots from the execution of the
% serial algorithm.
%
% Author :	Megasthenis Asteris
%
% Created:	March 01, 2010
% Edited :	May 27, 2010 

clc, clear all, close all
previous_path = addpath('../data', '../library'); rehash

N = 4;
DEMO = 2; % Set to 3 to pause during execution
% -------------------------------------------------------------------------
% Create random matrix V (N x 2), or load from file
%V = rand(N,2);
load V4x2_rank2_serial_example_1

[N, D] = size(V);
if (D ~= 2), %Check for the case the example is loaded from file
	error(sprintf('Invalid dimension D = %d.', D))
end
K = 2;

% Run the rank-2 serial algorithm
[S, STAT] = computeCandidateSupportsRank2Serial(V, K, DEMO);

% Print output ------------------------------------------------------------
for i = 1:length(STAT)
	fprintf('%s:', STAT(i).name);
    for j = 1:length(STAT(i).val)
        fprintf(' %f ', STAT(i).val(j));
    end
    fprintf('\n');
end

% Print the distinct sets
assert(size(S, 2) == K);
for i = 1:length(S)
    fprintf('[ ');
   for j = 1:K
       fprintf('%d ', S(i,j));
   end
   fprintf(']\n');
end
% -------------------------------------------------------------------------

% save V4x2_rank2_serial_example_1
% save2pdf('rank2-serial-V4x2-example-1-b', gcf, 600')

% Restore path
path(previous_path);



% The Sparse Principal Component of a Constant-rank Matrix
% -------------------------------------------------------------------------
% Run our algorithm to find the solution to the optimization problem
%     max    { x'VV'x }
%   ||x||=1
%   Card(x)<=K,
% where V is a N x D matrix with rank(V)=D.
% Compare result and execution time with the naive exhaustive search
% algorithm, i.e., the algorithm that compares all {N choose K} possible
% supports to determine the optimal one.
%
% Author : Megasthenis Asteris
%
% Created: March 01, 2010
% Edited : May 27, 2010

prevPath = addpath([ pwd, '/../library']); rehash;

N    = 20;   %the dimension of a column of V
K    = 10;    %the cardinality constraint of the x vector
RANK = 3;    %the rank of V

% artificially create A matrix (a rank-2, symmetric matrix)
V = 10*randn(N, RANK);

%--------------------------------------------------------------------------
fprintf('Running our (parallel) algorithm\n');
psrvmtime    = cputime;
[S STAT]     = computeCandidateSupports(V, K);
[x, maxVal] = findOptSolFromCandSets(V, S)
psrvmtime    = cputime-psrvmtime

fprintf('Running the exhaustive search method\n');
exhtime = cputime;
[ex_x, ex_maxVal] = findOptSolExhaustively(V, K)
exhtime = cputime-exhtime

% Restore path
path(prevPath);
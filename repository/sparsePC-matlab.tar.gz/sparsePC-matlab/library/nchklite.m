function comb = nchklite(n,k)

c = prod(n-(0:k-1))/factorial(k);
comb =  nchklite_recur(n, k, c);

%----------------------------------------
function comb = nchklite_recur(n, k, c)
comb = zeros(c, k);
is = 1;
if k>2
    for i=1:n-1
        rc = prod(n-i -(0:k-2))/factorial(k-1);
        ie = is+ rc- 1;
        comb(is:ie,1) = i;
        comb(is:ie,2:end) = i+nchklite_recur(n-i,k-1, rc);
        is = ie+1;
    end
elseif k == 2
    for i=1:n-1
        ie = is+(n-1-i);
        comb(is:ie,1) = i;
        comb(is:ie,2) = (i+1):n;
        is = ie+1;
    end
elseif k == 1
     comb(:) = 1:n;
end
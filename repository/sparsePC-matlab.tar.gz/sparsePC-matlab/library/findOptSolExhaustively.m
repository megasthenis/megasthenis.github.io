%% [X, OPTVAL] = FINDOPTSOLEXHAUSTIVELY(V, K)
% Computes the optimal vector x that solves
%             max (x'*V*V'*x)
%             st: || x ||_0 <= K,
%                 || x ||_2 = 1
% where V is a N x D matrix with rank equal to D.
% The function implements the naive exhaustive search
% algorithm, which compares all possible {N choose K}
% support sets to determine the optimal solution.

% Author :	Megasthenis Asteris
%
% Created:	March 10, 2010

function [x, optVal]= findOptSolExhaustively(V, K)

[N, D]  = size(V);
support = nchklite(N, K);

x = zeros(N,1);
optVal = 0;

for i=1:size(support,1)
    
    [U S] =svd( V(support(i,:),:) );
    
    %S(1,1) is the maximum possible value of the quadratic form.
    if ( abs(S(1,1)) > optVal )  
       optVal = S(1,1);
       x(:) = 0;
       x(support(i,:)) = U(:,1)/norm(U(:,1));
    end
    
end


%% C = FINDINTERSECTION(V)
% The cartesian coordinates of the intersection are calculated as the
% eigenvector of V corresponding to the smallest eigenvalue
function c = findIntersection(V)

[~, ~, C] = svd(V);
c = C(:, end);
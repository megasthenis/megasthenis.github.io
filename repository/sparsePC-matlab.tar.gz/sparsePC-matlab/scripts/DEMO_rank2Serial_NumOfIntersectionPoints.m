% The Sparse Principal Component of a Constant-rank Matrix
% -------------------------------------------------------------------------
% Run the "rank-2 serial algorithm" on a number of randomly constructed
% matrices V (N x 2).
% Plot the average number of points computed, as well as the average number
% of distinct candidate support sets returned by the algorithm.
%
% Author :  Megasthenis Asteris
%
% Created:  March 01, 2010
% Edited :  May 27, 2010 

clc, clear all, close all
prevPath = addpath([ pwd, '/../library']); rehash;

% Constants
Ns   = 6:2:50;             % values of N
Ks   = [ {'round(N/2)'} ]; % values of K (can be function of N)
EXP  = 10;

%==========================================================================
% Initialization
totNumOfInter     = zeros(length(Ks), length(Ns));
avgNumOfCompInter = zeros(length(Ks), length(Ns));
avgNumOfCandSupp  = zeros(length(Ks), length(Ns));
%==========================================================================

for k = 1:length(Ks);
    
    f = figure();
    xlabel(sprintf('$N$ (for K = %s)', Ks{k}), 'Interpreter', 'Latex');    
    for n = 1:length(Ns);

        N = Ns(n);
        K = eval(Ks{k});

        fprintf('N=%3d, K=%3d\n', N, K);

        totNumOfInter(k,n) = (N^2-N);

        % Experimental results
        ctr = 1;
        for e = 1:EXP

            try
                V = randn(N, 2);
                [S, STAT]= computeCandidateSupportsRank2Serial(V, K, 0);

                avgNumOfCompInter(k, n) =...
                    ((ctr-1)*avgNumOfCompInter(k, n)+ STAT(1).val )/ctr;
                avgNumOfCandSupp(k,n) =...
                    ((ctr-1)*avgNumOfCandSupp(k,n) + double(size(S, 1)))/ctr;
                ctr = ctr + 1;
            catch

            end
        end

        % Update figure
        h = [];
        h = [h, semilogy(Ns, totNumOfInter(k,:),...
            'Color', 'r', 'Linestyle', '--', 'LineWidth', 1.3)]; hold on;
        h = [h, semilogy(Ns, avgNumOfCompInter(k,:),...
            'Color', 'b', 'Linestyle', '-', 'LineWidth', 1.3)];
        h = [h, semilogy(Ns, avgNumOfCandSupp(k,:),...
            'Color', 'k', 'Linestyle', '-.', 'LineWidth', 1.3)];
        legend(h,...
               'Total # of intersection points',...
               'Avg # of intersection points computed',...
               'Avg # of distinct support sets',...
               'Location', 'NorthWest');  
        grid on;
    end
end

% Restore path
path(prevPath);